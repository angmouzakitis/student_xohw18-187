#ifndef _HLS_BUS_XACTOR_H_
#define _HLS_BUS_XACTOR_H_

#include <systemc>
#include <tlm.h>
#include "hls_bus_if.h"
using namespace tlm;


//--------------------------------------------------------
// Bus Xactor Datatype
//--------------------------------------------------------
#define addr_type unsigned

//------------------------------
// Bus request
//------------------------------
template <typename data_type>
class HLS_BusReq
{
public:
    bool req_din_type;
    unsigned int  req_size;
    addr_type  address;
    data_type  dataout;

    // Constructor
    HLS_BusReq()
    {
    }

    bool operator==( HLS_BusReq <data_type> &obj)
    {
        if( (obj.req_din_type == req_din_type) && (obj.req_size == req_size) && (obj.address == address) && (obj.dataout == dataout) )
             return true;
        else return false;
    }

    void reset()
    {
        req_din_type = false;
        req_size = 0;
        address  = 0;
        dataout  = 0;
    }

    void set(bool cmd, unsigned int size, addr_type addr, data_type data)
    {
       req_din_type = cmd;
       req_size = size;
       address  = addr;
       dataout  = data;
    }
};

#ifndef __SYNTHESIS__
template <typename data_type>
void sc_trace( sc_trace_file *tf, const HLS_BusReq <data_type>& obj,
const std::string& n )
{
sc_trace( tf, obj.dataout, n + "dataout" );
}
template <typename data_type>
ostream& operator << ( ostream& os, const HLS_BusReq <data_type> obj )
{
return os;
}
#endif

//------------------------------
// Bus response
//------------------------------
template <typename data_type>
class HLS_BusRsp
{
public:
    bool rsp_dout;
    data_type datain;

    // Constructor
    HLS_BusRsp()
    {
    }

    bool operator==( HLS_BusRsp <data_type> &obj)
    {
        if(obj.datain == datain )
             return true;
        else return false;
    }


    void reset()
    {
    }

    void set(bool rsp_type, data_type data)
    {
       rsp_dout = rsp_type;
       datain  = data;
    }
};

#ifndef __SYNTHESIS__
template <typename data_type>
void sc_trace( sc_trace_file *tf, const HLS_BusRsp <data_type>& obj,
const std::string& n )
{
sc_trace( tf, obj.datain, n + "datain" );
}
template <typename data_type>
ostream& operator << ( ostream& os, const HLS_BusRsp <data_type> obj )
{
return os;
}
#endif


//-------------------------------------------------------------------
// RTL Xactor
//-------------------------------------------------------------------
template <typename ESL_T>
SC_MODULE(BUS_RSP_Transactor) {
  public:
    // ESL interface.
    sc_port< tlm_fifo_get_if<HLS_BusRsp<ESL_T> > >bus_rsp_if;

    // RTL interface.
    sc_in_clk clock;
    sc_in< sc_logic > rst;

    sc_out< sc_logic > bus_if_rsp_empty_n;
    sc_in < sc_logic > bus_if_rsp_read;
    sc_out< ESL_T > bus_if_datain;

    ////////////////////////////////////////////////////////////////
    //sc_trace_file* mTrace;

    sc_signal<bool> reg_can_get;

    
    SC_CTOR( BUS_RSP_Transactor ) {
        SC_METHOD( thread_empty_n );
        sensitive << clock.pos();

        SC_METHOD( thread_dout );
        sensitive << clock.pos();
    }

    ~BUS_RSP_Transactor() {
        //sc_close_vcd_trace_file(mTrace);
    }
    
    void thread_empty_n() {
        //if (rst == SC_LOGIC_1) {
        //    bus_if_rsp_empty_n.write(SC_LOGIC_0);
        //} else {
            sc_logic tmpflag = sc_logic(bus_rsp_if->nb_can_get());
            /* cerr << "Time: " << sc_simulation_time() << " "
                 << name() 
                 << " empty_n=" << tmpflag << " " << bus_rsp_if->nb_can_get()
                 << endl;*/
            bus_if_rsp_empty_n.write(tmpflag);
        //}
        reg_can_get.write(bus_rsp_if->nb_can_get());
    }
    
    void thread_dout() {
        //if (rst == SC_LOGIC_1) {
        //    HLS_BusRsp<ESL_T> tmp;
        //    bus_if_datain.write(0);    //tmp.datain
        //} else {
            if (bus_if_rsp_read.read() == SC_LOGIC_1) {
                if (reg_can_get.read()) {
                    HLS_BusRsp<ESL_T> tmp;
                    bus_rsp_if->nb_get(tmp);
                }
            }
            HLS_BusRsp<ESL_T> tmp;
            (*(sc_port< tlm_get_peek_if<HLS_BusRsp<ESL_T> > >*)(&bus_rsp_if))->nb_peek(tmp);
            bus_if_datain.write(tmp.datain);
        //}
    }
};


template <typename ESL_T>
SC_MODULE(BUS_REQ_Transactor) {
  public:
    // ESL interface.
    sc_port< tlm_fifo_put_if< HLS_BusReq<ESL_T> > > bus_req_if;

    // RTL interface.
    sc_in_clk clock;
    sc_in < sc_logic > rst;

    sc_in < sc_logic >  bus_if_req_din;
    sc_out< sc_logic >  bus_if_req_full_n;
    sc_in < sc_logic >  bus_if_req_write;
    sc_in < sc_lv<32> > bus_if_address;
    sc_in < ESL_T >     bus_if_dataout;
    sc_in < sc_lv<32> > bus_if_size;

    ////////////////////////////////////////////////////////////////
    //sc_trace_file* mTrace;

    sc_signal<bool> reg_can_put;

    SC_CTOR( BUS_REQ_Transactor ) {
        //std::string tracefn = "sc_trace_" + std::string(name());
        //mTrace = sc_create_vcd_trace_file(tracefn.c_str());
        //sc_trace(mTrace, clock, "(port)clock");
        //sc_trace(mTrace, rst, "(port)rst");
        //sc_trace(mTrace, bus_if_req_full_n, "(port)bus_if_req_full_n");
        //sc_trace(mTrace, bus_if_req_write, "(port)bus_if_req_write");
        //sc_trace(mTrace, if_din, "(port)if_din");

        SC_METHOD( thread_run );
        sensitive << clock.pos();
    }

    ~BUS_REQ_Transactor() {
        //sc_close_vcd_trace_file(mTrace);
    }

    void thread_run() {
        reg_can_put.write(bus_req_if->nb_can_put());
        
        //if (rst == SC_LOGIC_1) {
        //    bus_if_req_full_n.write(SC_LOGIC_1);
        //} else {
            if (bus_if_req_write.read() == SC_LOGIC_1) {
                if (reg_can_put.read()) {
                    HLS_BusReq<ESL_T> tmp;
                    tmp.req_din_type = bus_if_req_din.read().to_bool();
                    tmp.req_size = bus_if_size.read().to_uint();
                    tmp.address = bus_if_address.read().to_uint();
                    tmp.dataout = bus_if_dataout.read();
                    bus_req_if->nb_put(tmp);
                }
            }

            bus_if_req_full_n.write(sc_logic(bus_req_if->nb_can_put()));
        //}
    }
    
};


//------------------------------------------------------------------------------
// TLM Xactor
//------------------------------------------------------------------------------
template <typename data_type>
class HLSBus_TLM_Xactor : public sc_module
{
  public:

    sc_in_clk clock;
    sc_in<sc_logic> rst;
    sc_port< tlm_fifo_put_if<HLS_BusRsp<data_type> > > bus_rsp;
    sc_port< tlm_fifo_get_if<HLS_BusReq<data_type> > > bus_req;

    hls_bus_port<data_type> bus_if;

    HLS_BusReq<data_type> req;
    HLS_BusRsp<data_type> rsp;

    unsigned int addr;           //record address for burst operation
    int size;                    //record size for burst operation

    data_type  *mem;             //internal memory space
    unsigned int m_start_addr;   //memory space start address
    unsigned int m_end_addr;     //memory space end address


    SC_HAS_PROCESS(HLSBus_TLM_Xactor);

    HLSBus_TLM_Xactor(sc_module_name _name
              ,unsigned int start_addr = 0
              ,unsigned int end_addr = 1024)
   :sc_module(_name)
   ,m_start_addr(start_addr)
   ,m_end_addr(end_addr)
   ,clock("clock")
   ,rst("rst")
   {
       sc_assert(m_start_addr <= m_end_addr);

       unsigned int size = (m_end_addr-m_start_addr+1);

       mem = new data_type [size];
       for (unsigned int i = 0; i < size; ++i)
         mem[i] = 0;

       SC_CTHREAD(prc1,clock.pos());
       //reset_signal_is(rst, SC_LOGIC_1);
   }

   void prc1()
   {
      rsp.rsp_dout = 0;
      while(true)
      {
        if(bus_req->nb_get(req))
        {
           addr = req.address;
           size = req.req_size;
           if(size==0) size=1;   //single read and write: size revision

           if(req.req_din_type)  //write
           { 
              for(int j=0;j<size;j++) 
              {
                if(j!=0) req = bus_req->get();
                mem[j] = req.dataout;
                //cout<<"[bus receiver]: write addr = "<<addr+j<<", data = "<<mem[addr+j]<<endl;
              }
              bus_if->burst_write(addr, size, mem);
           }
           else                  //read
           {
              bus_if->burst_read(addr, size, mem);
              for(int j=0;j<size;j++)
              {
                rsp.datain = mem[j];
                bus_rsp->put(rsp);
                //cout<<"[bus receiver]: read addr = "<<addr+j<<", data = "<<mem[addr+j]<<endl;
              }
           }
        }
        wait();
      }
   }

};


//--------------------------------------------------------------------------------
// HLSBus_Xactor
//--------------------------------------------------------------------------------
template <typename ESL_T>
SC_MODULE(HLSBus_Xactor)
{
  public:
  //RTL ports
  sc_in_clk clock;
  sc_in < sc_logic  > rst;
  sc_out< sc_logic  > bus_if_rsp_empty_n;
  sc_in < sc_logic  > bus_if_rsp_read;
  sc_out< ESL_T >     bus_if_datain;
  sc_in < sc_logic  > bus_if_req_din;
  sc_out< sc_logic  > bus_if_req_full_n;
  sc_in < sc_logic  > bus_if_req_write;
  sc_in < sc_lv<32> > bus_if_address;
  sc_in < ESL_T >     bus_if_dataout;
  sc_in < sc_lv<32> > bus_if_size;

  //TLM port
  hls_bus_port<ESL_T> bus_if;

  //sub-modules
  HLSBus_TLM_Xactor  <ESL_T>        m_HLSBus_TLM_Xactor;
  BUS_REQ_Transactor<ESL_T>  m_BUS_REQ_Transactor;
  BUS_RSP_Transactor<ESL_T>  m_BUS_RSP_Transactor;
  
  tlm_fifo <HLS_BusReq<ESL_T> > bus_req_chn;
  tlm_fifo <HLS_BusRsp<ESL_T> > bus_rsp_chn;

  SC_CTOR( HLSBus_Xactor )
  :m_HLSBus_TLM_Xactor("m_HLSBus_TLM_Xactor")
  ,m_BUS_REQ_Transactor("m_BUS_REQ_Transactor")
  ,m_BUS_RSP_Transactor("m_BUS_RSP_Transactor")
  ,bus_req_chn("bus_req_chn",6)
  ,bus_rsp_chn("bus_rsp_chn",6)
  {
      m_HLSBus_TLM_Xactor.clock(clock);
      m_HLSBus_TLM_Xactor.rst(rst);
      m_HLSBus_TLM_Xactor.bus_rsp(bus_rsp_chn);
      m_HLSBus_TLM_Xactor.bus_req(bus_req_chn);
      m_HLSBus_TLM_Xactor.bus_if(bus_if);

      m_BUS_REQ_Transactor.clock(clock);
      m_BUS_REQ_Transactor.rst(rst);
      m_BUS_REQ_Transactor.bus_if_req_din(bus_if_req_din);
      m_BUS_REQ_Transactor.bus_if_req_full_n(bus_if_req_full_n);
      m_BUS_REQ_Transactor.bus_if_req_write(bus_if_req_write);
      m_BUS_REQ_Transactor.bus_if_address(bus_if_address);
      m_BUS_REQ_Transactor.bus_if_dataout(bus_if_dataout);
      m_BUS_REQ_Transactor.bus_if_size(bus_if_size);
      m_BUS_REQ_Transactor.bus_req_if(bus_req_chn);

      m_BUS_RSP_Transactor.clock(clock);
      m_BUS_RSP_Transactor.rst(rst);
      m_BUS_RSP_Transactor.bus_if_rsp_empty_n(bus_if_rsp_empty_n);
      m_BUS_RSP_Transactor.bus_if_rsp_read(bus_if_rsp_read);
      m_BUS_RSP_Transactor.bus_if_datain(bus_if_datain);
      m_BUS_RSP_Transactor.bus_rsp_if(bus_rsp_chn);
  }

};

#undef addr_type
#endif
